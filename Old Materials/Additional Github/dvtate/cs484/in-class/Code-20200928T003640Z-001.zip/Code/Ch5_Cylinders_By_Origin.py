# Name: Ch5_Cylinders_By_Origin.py
# Creation Date: April 17, 2020
# Author: Ming-Long Lam

import matplotlib.pyplot as plt
import pandas

import graphviz
import sklearn.tree as tree

pandas.set_option('precision', 7)

inputData = pandas.DataFrame({'Cylinders': [3,4,5,6,8,10,12] * 3,
                              'Origin': ['Asia'] * 7 + ['Europe'] * 7 + ['USA'] * 7,
                              'vehicleCount': [1,74,0,69,12,0,0,0,25,7,54,34,0,3,0,37,0,67,41,2,0]})

X_train = inputData[['Cylinders']]
y_train = inputData['Origin']
w_train = inputData['vehicleCount']

classTree = tree.DecisionTreeClassifier(criterion = 'entropy', max_depth = 2, random_state = None)
thisFit = classTree.fit(X_train, y_train, sample_weight = w_train)

dot_data = tree.export_graphviz(classTree, out_file = None, impurity = True,
                                filled = True, proportion = False,
                                feature_names = ['Cylinders'], class_names = ['Asia', 'Europe', 'USA'])

graph = graphviz.Source(dot_data)

fig= plt.figure(figsize=(12,9), dpi = 1200)
graph

graph.render('C:\\Machine Learning Book\\Image\\Ch5_Cylinders_By_Origin_Tree', format = 'png')
