# Name: Ch8_GuessingGame_Compare.py
# Creation Date: June 30, 2020
# Author: Ming-Long Lam

import matplotlib.pyplot as plt
import numpy
import pandas

import graphviz
import sklearn.tree as tree
import statsmodels.api as stats

pandas.set_option('precision', 7)

def binary_model_evaluate (
   target,                   # Panda Series that contains values of target variable
   valueEvent,               # Formatted value of target variable that indicates an event
   valueNonEvent,            # Formatted value of target variable that indicates a non-event
   predProbEvent,            # Panda Series that contains predicted probability that the event will occur
   eventProbThreshold = 0.5  # Threshold for event probability to indicate a success
):

   # Separate the predicted probabilities according to the target values
   ppE_oE, freq_pE_oE = numpy.unique(predProbEvent[target == valueEvent], return_counts = True)
   ppE_oNE, freq_pE_oNE = numpy.unique(predProbEvent[target == valueNonEvent], return_counts = True)

   n_pE_oE = numpy.sum(freq_pE_oE)
   n_pE_oNE = numpy.sum(freq_pE_oNE)
   n_pE = n_pE_oE + n_pE_oNE
   print('Data Check:', valueEvent, n_pE_oE, valueNonEvent, n_pE_oNE)

   # Calculate the root average square error
   ase = (numpy.sum(freq_pE_oE * (1.0 - ppE_oE)**2) + numpy.sum(freq_pE_oNE * (0.0 - ppE_oNE)**2)) / n_pE
   if (ase > 0.0):
      rase = numpy.sqrt(ase)
   else:
      rase = 0.0

   # Calculate the misclassification error rate
   nFN = numpy.sum(freq_pE_oE[ppE_oE < eventProbThreshold])     # False Negative
   nFP = numpy.sum(freq_pE_oNE[ppE_oNE >= eventProbThreshold])  # False Positive
   mce = (nFP + nFN) / n_pE

   # Calculate the number of concordant, discordant, and tied pairs
   nConcordant = 0.0
   nDiscordant = 0.0
   nTied = 0.0

   # Loop over the predicted event probabilities from the Event column
   for eProb, eFreq in zip(ppE_oE, freq_pE_oE):
      _thisC = eFreq * numpy.sum(freq_pE_oNE[ppE_oNE < eProb])
      _thisD = eFreq * numpy.sum(freq_pE_oNE[ppE_oNE > eProb])
      _thisT = eFreq * numpy.sum(freq_pE_oNE[ppE_oNE == eProb])      
      nConcordant = nConcordant + _thisC
      nDiscordant = nDiscordant + _thisD
      nTied = nTied + _thisT

   # Calculate Area Under Curve and Gini Coefficient
   auc = 0.5 + 0.5 * (nConcordant - nDiscordant) / (nConcordant + nDiscordant + nTied)
   gini = auc + auc - 1.0

   # Calculate Goodman-Kruskal Gamma
   gk_gamma = (nConcordant - nDiscordant) / (nConcordant + nDiscordant)

   # Generate Receiver Operating Characteristic curve coordinates
   pThreshold = numpy.unique(numpy.concatenate((ppE_oE, ppE_oNE)))
   nThreshold = len(pThreshold)
   rocCoordinate = numpy.zeros(((nThreshold+2),3))
   prCoordinate = numpy.zeros(((nThreshold+1),4))
   ksThreshold = numpy.NaN
   ksStat = -1.0

   rocCoordinate[0:] = [numpy.NaN, 0.0, 0.0]               # Add dummy point (0,0)
   prCoordinate[0,:] = [numpy.NaN, 0.0, 1.0, numpy.NaN]    # Add dummy point (0,1)
   for i in range(nThreshold):
      thresh = pThreshold[nThreshold-i-1]
      nFN = numpy.sum(freq_pE_oE[ppE_oE < thresh])
      nFP = numpy.sum(freq_pE_oNE[ppE_oNE >= thresh])
      nTP = n_pE_oE - nFN
      sensitivity = 1.0 - (nFN / n_pE_oE)
      oneMinusSpecificity = nFP / n_pE_oNE
      precision = nTP / (nTP + nFP)
      if (precision > 0.0 and sensitivity > 0.0):
         f1Score =  2.0 / (1.0 / precision + 1.0 / sensitivity)
      else:
         f1Score = 0.0
      gapDistance = sensitivity - oneMinusSpecificity
      if (gapDistance > ksStat):
         ksThreshold = thresh
         ksStat = gapDistance

      rocCoordinate[i+1:] = [thresh, oneMinusSpecificity, sensitivity]
      prCoordinate[i+1,:] = [thresh, sensitivity, precision, f1Score]

   rocCoordinate[nThreshold+1:] = [numpy.NaN, 1.0, 1.0]    # Add dummy point (1,1)
      
   modelStat = pandas.Series({'NOBS': n_pE, 'ASE': ase, 'RASE': rase,
                              'NFP': nFP, 'NFN': nFN, 'MCE': mce, 
                              'NCONCORDANT': nConcordant, 'NDISCORDANT': nDiscordant, 'NTIED': nTied,
                              'AUC': auc, 'GINI': gini, 'GAMMA': gk_gamma,
                              'K-S': ksStat, 'K-S THRESHOLD': ksThreshold})

   return(modelStat, rocCoordinate, prCoordinate)

# The Gain and Lift function
def compute_lift_coordinate (
   target,          # The column that holds the dependent variable's values
   valueEvent,      # Value of the dependent variable that indicates an event
   predProbEvent):  # The column that holds the predicted event probability

    # Find out the number of observations
    nObs = len(target)

    # Get the quantiles
    quantileCutOff = numpy.unique(numpy.percentile(predProbEvent, numpy.arange(0, 100, 10)))
    nQuantile = len(quantileCutOff)

    quantileIndex = numpy.zeros(nObs)
    for i in range(nObs):
        iQ = nQuantile
        EPP = predProbEvent[i]
        for j in range(1, nQuantile):
            if (EPP >= quantileCutOff[-j]):
                iQ -= 1
        quantileIndex[i] = iQ

    # Construct the Lift chart table
    countTable = pandas.crosstab(quantileIndex, target)
    decileN = countTable.sum(1)
    decilePct = 100 * (decileN / nObs)
    gainN = countTable[valueEvent]
    totalNResponse = gainN.sum(0)
    gainPct = 100 * (gainN /totalNResponse)
    responsePct = 100 * (gainN / decileN)
    overallResponsePct = 100 * (totalNResponse / nObs)
    lift = responsePct / overallResponsePct

    liftCoordinate = pandas.concat([decileN, decilePct, gainN, gainPct, responsePct, lift],
                                    axis = 1, ignore_index = True)
    liftCoordinate = liftCoordinate.rename({0:'Decile N',
                                            1:'Decile %',
                                            2:'Gain N',
                                            3:'Gain %',
                                            4:'Response %',
                                            5:'Lift'}, axis = 'columns')

    # Construct the Cumulative Lift chart table
    cumCountTable = countTable.cumsum(axis = 0)
    decileN = cumCountTable.sum(1)
    decilePct = 100 * (decileN / nObs)
    gainN = cumCountTable[valueEvent]
    gainPct = 100 * (gainN / totalNResponse)
    responsePct = 100 * (gainN / decileN)
    lift = responsePct / overallResponsePct

    cumLiftCoordinate = pandas.concat([decileN, decilePct, gainN, gainPct, responsePct, lift],
                                       axis = 1, ignore_index = True)
    cumLiftCoordinate = cumLiftCoordinate.rename({0:'Cumulative Decile N',
                                                  1:'Cumulative Decile %',
                                                  2:'Cumulative Gain N',
                                                  3:'Cumulative Gain %',
                                                  4:'Cumulative Response %',
                                                  5:'Cumulative Lift'}, axis = 'columns')

    return(quantileCutOff, liftCoordinate, cumLiftCoordinate)

yName = 'y'
xName = ['x1', 'x2']

inputData = pandas.read_csv('C:\\Machine Learning Book\\Data\\GuessingGame.csv',
                            delimiter = ',', header = 0, usecols = xName + [yName])

inputData = inputData.dropna()

print('Frequency Table:\n',inputData.groupby('y').size())

X_train = inputData[xName]
y_train = inputData[yName]

# STEP 1: Train the classification tree
classTree = tree.DecisionTreeClassifier(criterion = 'entropy', max_depth = 6, random_state = None)
thisFit = classTree.fit(X_train, y_train)
predProb_tree = thisFit.predict_proba(X_train)

print('Number of Leaves = ', classTree.tree_.node_count)
dot_data = tree.export_graphviz(classTree, out_file = None, impurity = True,
                                filled = True, proportion = False,
                                feature_names = xName, class_names = ['LOSE', 'WIN'])

graph = graphviz.Source(dot_data)

graph

# STEP 2: Train the logistic regression
designX = stats.add_constant(X_train, prepend = True)
logit = stats.MNLogit(y_train, designX)
thisFit = logit.fit(method='newton', maxiter = 100, gtol = 1e-6, full_output = True, disp = True)
predProb_logistic = thisFit.predict(designX)

print(thisFit.summary())

# STEP 3: Evaluate both models
modelStat_tree, rocCoord_tree, prCoord_tree = binary_model_evaluate (y_train, 'WIN', 'LOSE', predProb_tree[:,1])
print('Model Statistics for Classification Tree:\n', modelStat_tree)

decile_tree, liftCoord_tree, cumLiftCoord_tree = compute_lift_coordinate (y_train, 'WIN', predProb_tree[:,1])

modelStat_logreg, rocCoord_logreg, prCoord_logreg = binary_model_evaluate (y_train, 'WIN', 'LOSE', predProb_logistic[1])
print('Model Statistics for Logistic Regression:\n', modelStat_logreg)

decile_logreg, liftCoord_logreg, cumLiftCoord_logreg = compute_lift_coordinate (y_train, 'WIN', predProb_logistic[1])

# Receiver Operating Characteristic Curve
plt.plot(rocCoord_tree[:,1], rocCoord_tree[:,2], 'r-', label = 'Classification Tree')
plt.plot(rocCoord_logreg[:,1], rocCoord_logreg[:,2], 'b-', label = 'Logistic Regression')
plt.xticks(numpy.arange(0,1.1,0.1))
plt.yticks(numpy.arange(0,1.1,0.1))
plt.xlabel('1 - Specificity')
plt.ylabel('Sensitivity')
plt.grid(axis = 'both')
plt.legend(title = 'Algorithm:')
plt.show()

# Kolmogorov-Smirnov Chart
plt.plot(rocCoord_tree[:,0], rocCoord_tree[:,1], 'g-', label = 'False Positive')
plt.plot(rocCoord_tree[:,0], rocCoord_tree[:,2], 'r-', label = 'True Positive')
plt.xticks(numpy.arange(0,1.1,0.1))
plt.yticks(numpy.arange(0,1.1,0.1))
plt.ylabel('Positive Rate')
plt.xlabel('Threshold')
plt.grid(axis = 'both')
plt.title('Classification Tree')
plt.show()

plt.plot(rocCoord_logreg[:,0], rocCoord_logreg[:,1], 'g-', label = 'False Positive')
plt.plot(rocCoord_logreg[:,0], rocCoord_logreg[:,2], 'r-', label = 'True Positive')
plt.xticks(numpy.arange(0,1.1,0.1))
plt.yticks(numpy.arange(0,1.1,0.1))
plt.ylabel('Positive Rate')
plt.xlabel('Threshold')
plt.grid(axis = 'both')
plt.title('Logistic Regression')
plt.show()

# Kolmogorov-Smirnov statistic chart
plt.plot(rocCoord_tree[:,0], (rocCoord_tree[:,2]-rocCoord_tree[:,1]), 'g-', label = 'Classification Tree')
plt.plot(rocCoord_logreg[:,0], (rocCoord_logreg[:,2]-rocCoord_logreg[:,1]), 'r-', label = 'Logistic Regression')
plt.xticks(numpy.arange(0,1.1,0.1))
plt.yticks(numpy.arange(0,1.1,0.1))
plt.ylabel('True Positive - False Positive')
plt.xlabel('Threshold')
plt.grid(axis = 'both')
plt.legend(title = 'Algorithm:')
plt.show()

# Precision Recall Curve
noSkill = numpy.count_nonzero(y_train == 'WIN') / len(y_train)
plt.plot(prCoord_tree[:,1], prCoord_tree[:,2], 'g-', label = 'Classification Tree')
plt.plot(prCoord_logreg[:,1], prCoord_logreg[:,2], 'r-', label = 'Logistic Regression')
plt.hlines(noSkill, 0.0, 1.0, colors = 'blue', linestyles = 'dashed', label = 'No Skill')
plt.xticks(numpy.arange(0,1.1,0.1))
plt.yticks(numpy.arange(0,1.1,0.1))
plt.xlabel('Recall')
plt.ylabel('Precision')
plt.grid(axis = 'both')
plt.legend(title = 'Algorithm:')
plt.show()

# F1 Score Curve
plt.plot(prCoord_tree[:,0], prCoord_tree[:,3], 'g-', label = 'Classification Tree')
plt.plot(prCoord_logreg[:,0], prCoord_logreg[:,3], 'r-', label = 'Logistic Regression')
plt.xticks(numpy.arange(0,1.1,0.1))
plt.xlabel('Threshold')
plt.ylabel('F1 Score')
plt.grid(axis = 'both')
plt.legend(title = 'Algorithm:')
plt.show()

# Lift Curve
plt.plot(liftCoord_tree.index, liftCoord_tree['Lift'], 'go-', label = 'Classification Tree')
plt.plot(liftCoord_logreg.index, liftCoord_logreg['Lift'], 'rs-', label = 'Logistic Regression')
plt.xticks(numpy.arange(1,11,1))
plt.yticks(numpy.arange(0,4.0,0.5))
plt.xlabel('Decile of Descending Predicted Event Probability')
plt.ylabel('Lift')
plt.grid(axis = 'both')
plt.legend(title = 'Algorithm:')
plt.show()

plt.plot(cumLiftCoord_tree.index, cumLiftCoord_tree['Cumulative Lift'], 'go-', label = 'Classification Tree')
plt.plot(cumLiftCoord_logreg.index, cumLiftCoord_logreg['Cumulative Lift'], 'rs-', label = 'Logistic Regression')
plt.xticks(numpy.arange(1,11,1))
plt.yticks(numpy.arange(1,4.0,0.5))
plt.xlabel('Cumulative Decile of Descending Predicted Event Probability')
plt.ylabel('Cumulative Lift')
plt.grid(axis = 'both')
plt.legend(title = 'Algorithm:')
plt.show()
