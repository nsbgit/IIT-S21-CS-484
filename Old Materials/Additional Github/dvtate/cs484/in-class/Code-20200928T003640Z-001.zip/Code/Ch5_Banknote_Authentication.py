# Name: Ch5_Bank_Authentication.py
# Creation Date: April 17, 2020
# Author: Ming-Long Lam

import matplotlib.pyplot as plt
import numpy
import pandas

import graphviz
import sklearn.tree as tree

pandas.set_option('precision', 7)

# Data source: http://archive.ics.uci.edu/ml/datasets/banknote+authentication
yName = 'authentication'
xName = ['variance_wavelet_image', 'skewness_wavelet_image',
         'kurtosis_wavelet_image', 'entropy_image']

inputData = pandas.read_csv('http://archive.ics.uci.edu/ml/machine-learning-databases/00267/data_banknote_authentication.txt',
                            delimiter = ',', header = None, names = xName + [yName])

inputData = inputData.dropna()

inputData[yName] = inputData[yName].map({0: 'genuine', 1: 'forged'})

# STEP 1: Explore the data

# See the distribution of the target variable
print(inputData.groupby(yName).size())

# Draw boxplots of the interval predictors by levels of the target variable
for ivar in xName:
   inputData.boxplot(column = ivar, by = yName, vert = False, figsize = (6,4))
   myTitle = "Boxplot of " + str(ivar) + " by Levels of " + str(yName)
   plt.title(myTitle)
   plt.suptitle("")
   plt.xlabel(ivar)
   plt.ylabel(yName)
   plt.grid(axis="y")
   plt.show()

# STEP 2: Train the classification tree

X_train = inputData[xName]

y_train = inputData[yName]

classTree = tree.DecisionTreeClassifier(criterion = 'entropy', max_depth = 3, 
                                        min_samples_leaf = 0.1, random_state = None)

thisFit = classTree.fit(X_train, y_train)

# STEP 3: Visualize the classification tree

dot_data = tree.export_graphviz(classTree, out_file = None, impurity = True,
                                filled = True, proportion = False,
                                feature_names = xName, class_names = ['forged', 'genuine'])

graph = graphviz.Source(dot_data)

fig= plt.figure(figsize=(12,9), dpi = 1200)
graph

graph.render('C:\\Machine Learning Book\\Image\\Ch5_Banknote_Authentication_Tree', format = 'png')
