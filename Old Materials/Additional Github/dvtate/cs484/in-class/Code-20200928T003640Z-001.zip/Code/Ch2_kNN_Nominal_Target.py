# Name: Ch2_kNN_Nominal_Target.py
# Creation Date: February 24, 2020
# Author: Ming-Long Lam

# Load the necessary library
import matplotlib.pyplot as plt
import numpy
import pandas
import sklearn.neighbors as neighbors

pandas.set_option('display.max_columns', None)
pandas.set_option('display.max_rows', None)

# Specify the input and the target variables
inputVar = ['Variance_Image', 'Skewness_Image', 'Kurtosis_Image', 'Entropy_Image']

targetVar =  'Authenticity'

# Read the banknote data from the UCI site into the bankNote dataframe
bankNote = pandas.read_csv('https://archive.ics.uci.edu/ml/machine-learning-databases/00267/data_banknote_authentication.txt',
                           sep = ',', header = None)

bankNote = bankNote.rename(columns = {0:inputVar[0], 1:inputVar[1], 2:inputVar[2], 3:inputVar[3], 4:targetVar})

# Look at distribution of y
_u_, _c_ = numpy.unique(bankNote[targetVar], return_counts = True)
print(_u_, _c_)

plt.bar(_u_, _c_, align = 'center')
plt.xlabel(targetVar)
plt.ylabel('Frequency')
plt.xticks(numpy.arange(0,2,1))
plt.grid(axis = 'y')
plt.show()

# Look at the distribution of input features
for pred in inputVar:
    bankNote.boxplot(column = [pred], by = targetVar, vert = False)
    plt.title('Boxplot of ' + pred + ' by Levels of ' + targetVar)
    plt.suptitle("")
    plt.xlabel(pred)
    plt.ylabel(targetVar)
    plt.grid(axis="y")
    plt.show()

# Specify the input variables ('Variance_Image', 'Skewness_Image', 'Kurtosis_Image')
X = bankNote[inputVar[0:3]]

# Specify y as the target variable
y = bankNote[targetVar]

# Get the minimum value of y
y_min = numpy.min(y)

y = y.astype('category')

# Get the number of observations
nObs = len(y)

# Prepare a dataframe for storing the RASE metric
misClassRate_orig = pandas.DataFrame(columns = ['k', 'Misclassification Rate'])

# Specify the maximum number of neighbors
kMax = 10

# Obtain the k-Nearest Neighbors solution
for i in range(kMax):
    k = i + 1
    nbrs = neighbors.KNeighborsClassifier(n_neighbors = k, algorithm = 'brute', metric = 'euclidean')
    model = nbrs.fit(X, y)

    # Calculate the predicted target probabilities
    yPredictProb = model.predict_proba(X)

    # Calculate the predicted target class
    yPredict = y_min + numpy.argmax(yPredictProb, axis = 1)
  
    MCE = numpy.sum(numpy.where(y == yPredict, 0, 1)) / nObs
    misClassRate_orig.loc[i] = [k, MCE]

print('\n--- Misclassification Rate ---\n', misClassRate_orig)

# Plot the Misclassification Rate versus the Number of Neighbors
plt.plot(misClassRate_orig['k'], misClassRate_orig['Misclassification Rate'],
         marker = 'o', color = 'blue', linestyle = 'solid', linewidth = 2, markersize = 6)
plt.grid(True)
plt.xlabel('Number of Neighbors (k)')
plt.ylabel('Misclassification Rate')
plt.xticks(numpy.arange(1,(kMax+1)))
plt.show()

# Print correlations among the input variables
corrX = X.corr(method = 'pearson')
print('\n--- Correlation Matrix ---\n', numpy.round(corrX, 4))

X = numpy.matrix(bankNote[inputVar[0:3]].values)
xtx = X.transpose() * X

# Eigenvalue decomposition
evals, evecs = numpy.linalg.eigh(xtx)

# Here is the transformation matrix
transf = evecs * numpy.linalg.inv(numpy.sqrt(numpy.diagflat(evals)));

# Here is the transformed X
transf_x = X * transf;
print("The Transformed x = \n", transf_x)

# Check that columns of transformed X are orthonormalized
print("Expect an Identity Matrix = \n", numpy.round(transf_x.transpose() * transf_x, 3))

# Prepare a dataframe for storing the RASE metric
misClassRate_orth = pandas.DataFrame(columns = ['k', 'Misclassification Rate'])

# Obtain the k-Nearest Neighbors solution
for i in range(kMax):
    k = i + 1
    nbrs = neighbors.KNeighborsClassifier(n_neighbors = k, algorithm = 'brute', metric = 'euclidean')
    model = nbrs.fit(transf_x, y)

    # Calculate the predicted target probabilities
    yPredictProb = model.predict_proba(transf_x)

    # Calculate the predicted target class
    yPredict = y_min + numpy.argmax(yPredictProb, axis = 1)
  
    MCE = numpy.sum(numpy.where(y == yPredict, 0, 1)) / nObs
    misClassRate_orth.loc[i] = [k, MCE]

print('\n--- Misclassification Rate ---\n', misClassRate_orth)

# Plot the Misclassification Rate versus the Number of Neighbors
plt.plot(misClassRate_orth['k'], misClassRate_orth['Misclassification Rate'],
         marker = 'o', color = 'blue', linestyle = 'solid', linewidth = 2, markersize = 6)
plt.grid(True)
plt.xlabel('Number of Neighbors (k)')
plt.ylabel('Misclassification Rate')
plt.xticks(numpy.arange(1,(kMax+1)))
plt.show()

# Plot the Misclassification Rate versus the Number of Neighbors
plt.plot(misClassRate_orig['k'], misClassRate_orig['Misclassification Rate'], label = 'Original',
         marker = 'o', color = 'blue', linestyle = 'solid', linewidth = 2, markersize = 6)
plt.plot(misClassRate_orth['k'], misClassRate_orth['Misclassification Rate'], label = 'Orthonormalized',
         marker = 'o', color = 'red', linestyle = 'solid', linewidth = 2, markersize = 6)
plt.grid(True)
plt.xlabel('Number of Neighbors (k)')
plt.ylabel('Misclassification Rate')
plt.xticks(numpy.arange(1,(kMax+1)))
plt.legend(loc = 'upper left')
plt.show()
