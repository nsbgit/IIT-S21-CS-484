# Name: Ch3_Association_Rule_Toy.py
# Creation Date: March 20, 2020
# Author: Ming-Long Lam

# Load the necessary library
import numpy
import pandas
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori
from mlxtend.frequent_patterns import association_rules

pandas.set_option('display.max_columns', None)
pandas.set_option('display.max_rows', None)

# Read the Sale Receipt data
SaleReceipt = pandas.read_csv('C:\\Machine Learning Book\\Data\\association_rule_toy.csv', delimiter=',')

# Convert the Sale Receipt data to the Item List format
ListItem = SaleReceipt.groupby(['Transaction'])['Item'].apply(list).values.tolist()

# Convert the Item List format to the Item Indicator format
te = TransactionEncoder()
te_ary = te.fit(ListItem).transform(ListItem)
ItemIndicator = pandas.DataFrame(te_ary, columns = te.columns_)

# Find the frequent itemsets
frequent_itemsets = apriori(ItemIndicator, min_support = 0.3, max_len = 2, use_colnames = True)

# Discover the association rules
assoc_rules = association_rules(frequent_itemsets, metric = 'confidence', min_threshold = 0.5)

# Find all the possible association rules
import matplotlib.pyplot as plt

# Find the frequent itemsets
all_frequent_itemsets = apriori(ItemIndicator, min_support = 0.05, max_len = 4, use_colnames = True)

# Discover the association rules
all_assoc_rules = association_rules(all_frequent_itemsets, metric = 'confidence', min_threshold = 1.0e-13)

# Plot the Confidence versus the Support
plt.figure(figsize=(8,6))
plt.scatter(all_assoc_rules['confidence'], all_assoc_rules['support'], s = 100*all_assoc_rules['lift'],
            c = all_assoc_rules['lift'], marker = 'o')
plt.grid(True)
plt.xlabel('Confidence')
plt.ylabel('Support')
plt.xticks(numpy.arange(0.0, 1.1, step = 0.1))
plt.yticks(numpy.arange(0.0, 1.1, step = 0.1))
plt.colorbar(label = 'Lift')
plt.show()
