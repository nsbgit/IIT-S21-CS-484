# Name: Ch8_Random_Sampling.py
# Creation Date: June 30, 2020
# Author: Ming-Long Lam

import numpy

# Development of Sampling Plans by Using Sequential (Item by Item) Selection Techniques and Digital Computers
# Author(s): C. T. Fan, Mervin E. Muller and Ivan Rezucha
# Source: Journal of the American Statistical Association, Vol. 57, No. 298 (Jun., 1962), pp.387-402

import random

def algorithmSRS (n, k):
   j = 0
   outIndex = []
   for i in range(n):
      if (j < k):
         u = random.random()
         if (((k - j) / (n - i)) > u):
            j = j + 1
            outIndex.append(i)
   return outIndex

# Here are the six letters
x = numpy.array(['A','B','C','D','E', 'F'])
n = len(x)

# Initialize the random seed
random.seed(27513)

# Select a simple random sample of four letters
oneIndex = algorithmSRS(n, 4)
SRSample = x[oneIndex]
print(SRSample)

# Here are the six letters in two strata
s = numpy.array([0, 1, 0, 1, 0, 1])

# Initialize the random seed
random.seed(27513)

# Original sampling rate
sampRate = 4 / 6

# Select a stratified random sample o four letters
strataSample = numpy.empty(0, dtype = str)
for row in range(2):
    x_S = x[numpy.where(s == row)]
    n_S = len(x_S)
    k = numpy.around(sampRate * n_S)
    oneIndex = algorithmSRS(n_S, k)
    sample_S = x_S[oneIndex]
    strataSample = numpy.concatenate((strataSample, sample_S))

print(strataSample)

