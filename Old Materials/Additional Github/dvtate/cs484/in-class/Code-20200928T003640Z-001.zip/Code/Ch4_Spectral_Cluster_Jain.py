# Name: Ch_Spectral_Cluster-Jain.py
# Creation Date: April 11, 2020
# Author: Ming-Long Lam

import math
import matplotlib.pyplot as plt
import numpy
import pandas

import numpy.linalg as linalg
import sklearn.cluster as cluster
import sklearn.neighbors as neighbors

Spiral = pandas.read_csv('http://cs.joensuu.fi/sipu/datasets/jain.txt', header = None, delimiter = '\t',
                         names = ['x', 'y', 'group'])

nObs = Spiral.shape[0]

plt.scatter(Spiral['x'], Spiral['y'], c = Spiral['group'])
plt.xlabel('x')
plt.ylabel('y')
plt.xticks(numpy.arange(0,50,5))
plt.yticks(numpy.arange(0,35,5))
plt.grid(True)
plt.show()

numberOfNeighbors = numpy.floor(numpy.log(nObs)).astype(int) + 1

# K-nearest neighbor
trainData = Spiral[['x','y']]
kNNSpec = neighbors.NearestNeighbors(n_neighbors = numberOfNeighbors,
                                     algorithm = 'brute', metric = 'euclidean')
nbrs = kNNSpec.fit(trainData)
d3, i3 = nbrs.kneighbors(trainData)

# Retrieve the distances among the observations
distObject = neighbors.DistanceMetric.get_metric('euclidean')
distances = distObject.pairwise(trainData)

# Create the Adjacency matrix
Adjacency = numpy.zeros((nObs, nObs))
for i in range(nObs):
    for j in i3[i]:
        Adjacency[i,j] = math.exp(- (distances[i][j])**2 )

# Make the Adjacency matrix symmetric
Adjacency = 0.5 * (Adjacency + Adjacency.transpose())

# Create the Degree matrix
Degree = numpy.zeros((nObs, nObs))
for i in range(nObs):
    sum = 0.0
    for j in range(nObs):
        sum += Adjacency[i,j]
    Degree[i,i] = sum

# Create the Laplacian matrix        
Lmatrix = Degree - Adjacency

averageTraceL = numpy.trace(Lmatrix) / nObs

# Obtain the eigenvalues and the eigenvectors of the Laplacian matrix
evals, evecs = linalg.eigh(Lmatrix)

# Check if an eigenvalue is considered zero
for i in range(10):
    print('i = %2d, Eigenvalue = %.14e Criterion = %.14e' % (i, evals[i,], (evals[i,] / averageTraceL)))

# Series plot of the first ten eigenvalues to determine the number of clusters
sequence = numpy.arange(1,11,1)
plt.plot(sequence, evals[0:10,], marker = 'o')
plt.xlabel('Sequence')
plt.ylabel('Eigenvalue')
plt.xticks(sequence)
plt.grid('both')
plt.show()

# Do K-means on the two eigenvectors that correspond to the two smallest eigenvalues
Z = evecs[:,[0,1]]

plt.scatter(Z[:,0], Z[:,1])
plt.xlabel('First Eigenvector (z1)')
plt.ylabel('Second Eigenvector (z2)')
plt.grid(True)
plt.show()


# Perform 2-cluster K-mean on the first two eigenvectors
kmeans_spectral = cluster.KMeans(n_clusters = 2, random_state = 0).fit(Z)
Spiral['SpectralCluster'] = kmeans_spectral.labels_

# Visually check the spectral clustering results
plt.scatter(Spiral['x'], Spiral['y'], c = Spiral['SpectralCluster'])
plt.xlabel('x')
plt.ylabel('y')
plt.grid(True)
plt.show()
