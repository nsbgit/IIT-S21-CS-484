# Name: Ch2_kNN_Interval_Target.py
# Creation Date: February 21, 2020
# Author: Ming-Long Lam

# Load the necessary library
import matplotlib.pyplot as plt
import numpy
import pandas
import sklearn.neighbors as neighbors

# Manually enter the data into the tenObs dataframe
tenObs = pandas.DataFrame({'CaseID': [1,2,3,4,5,6,7,8,9,10],
                           'x1': [7.7, 9.5, 3.0, 9.1, 2.2, 4.8, 5.5, 10, 4.2, 1.6],
                           'x2': [-37, -38, -34, -75, -31, -7, -6, -61, -23, -54],
                           'y': [4, 1, 2, 1, 2, 4, 3, 1, 2, 1]})

# Set CaseID as the index for the tenObs dataframe
tenObs = tenObs.set_index('CaseID')

# Specify x1 and x2 as the input variables
X = tenObs[['x1', 'x2']]

# Specify y as the target variable
y = tenObs['y']

# Get the number of observations
nObs = len(y)

# Calculate the distances among the observations
distObject = neighbors.DistanceMetric.get_metric('euclidean')
distances = distObject.pairwise(X)

print('\n--- Pairwise Distance Between Observations ---\n', distances)

# Prepare a dataframe for storing the RASE metric
rootAveSqError = pandas.DataFrame(columns = ['k', 'rootAveSqError'])

# Obtain the k-Nearest Neighbors solution
for i in range(nObs):
    k = i + 1

    nbrs = neighbors.KNeighborsRegressor(n_neighbors = k , algorithm = 'brute', metric = 'euclidean')
    model = nbrs.fit(X, y)

    # Calculate the predicted target value
    yPredict = model.predict(X)
    errorPredict = y - yPredict
    rase = numpy.sqrt(numpy.sum(errorPredict * errorPredict) / nObs)
    rootAveSqError.loc[i] = [k, rase]

print('\n--- Root Average Squared Error ---\n', rootAveSqError)

# Plot the Root Average Squared Error versus the Number of Neighbors
plt.plot(rootAveSqError['k'], rootAveSqError['rootAveSqError'],
         marker = 'o', color = 'blue', linestyle = 'solid', linewidth = 2, markersize = 6)
plt.grid(True)
plt.xlabel('Number of Neighbors (k)')
plt.ylabel('Root Average Squared Error')
plt.xticks(numpy.arange(1,(nObs+1)))
plt.yticks(numpy.arange(0,1.3,0.2))
plt.show()
