# Name: Ch8_PriceChallenge_Compare.py
# Creation Date: June 30, 2020
# Author: Ming-Long Lam

import matplotlib.pyplot as plt
import numpy
import pandas

import graphviz
import sklearn.tree as tree
import statsmodels.api as stats

from sklearn.model_selection import train_test_split

pandas.set_option('precision', 7)

def NominalMetric (y, predProb):
   
   n = predProb.shape[0]          # Number of observations
   K = predProb.shape[1]          # Number of target categories

   # Retrieve target categories
   y_cat = predProb.columns

   # Predicted target category
   j_max = predProb.values.argmax(axis = 1)
   predYCat = y_cat[j_max]

   # Misclassification rate
   qMisClass = numpy.where(predYCat == y, 0, 1)

   # Root Average Squared Error
   delta = pandas.DataFrame(numpy.zeros((n,K)), columns = y_cat)
   for col in y_cat:
      delta[col] = numpy.where(y == col, 1.0, 0.0)
   obsAse = numpy.mean((delta - predProb) ** 2, axis = 1)
   ase = numpy.mean(obsAse)
   
   # Area Under Curve
   nComb = 0
   auc = 0.0
   for row in y_cat:
      eProb = predProb[row][y == row]
      for col in y_cat:
         if (row != col):
            neProb = predProb[row][y == col]

            # Calculate the number of concordant, discordant, and tied pairs
            nConcordant = 0
            nDiscordant = 0
            nTied = 0
            for eP in eProb:
               nConcordant = nConcordant + numpy.sum(numpy.where(neProb < eP, 1, 0))
               nDiscordant = nDiscordant + numpy.sum(numpy.where(neProb > eP, 1, 0))
               nTied = nTied + numpy.sum(numpy.where(neProb == eP, 1, 0))
            nPairs = nConcordant + nDiscordant + nTied
            if (nPairs > 0):
               nComb = nComb + 1
               auc = auc + 0.5 + 0.5 * (nConcordant - nDiscordant) / nPairs
   if (nComb > 0):
      auc = auc / nComb
   else:
      auc = numpy.nan

   outMetric = pandas.Series({'MCE': numpy.mean(qMisClass),
                              'ASE': ase,
                              'RASE': numpy.sqrt(ase),
                              'AUC': auc})
   return (outMetric, predYCat, qMisClass, obsAse)

yName = 'outcome'
xName = ['nPenny', 'nNickel', 'nDime', 'nQuarter', 'nDollar']

inputData = pandas.read_csv('C:\\Machine Learning Book\\Data\\PriceChallenge.csv',
                            delimiter = ',', header = 0, usecols = xName + [yName])

inputData = inputData.dropna()

X_train, X_test, y_train, y_test = train_test_split(inputData[xName], inputData[yName], stratify = inputData[yName],
                                                    test_size = 0.3, random_state = 4325879)
X_train.reset_index(drop = True, inplace = True)
X_test.reset_index(drop = True, inplace = True)

y_train.reset_index(drop = True, inplace = True)
y_test.reset_index(drop = True, inplace = True)

yCat, yFreq = numpy.unique(y_train, return_counts = True)
nObs = y_train.shape[0]
yRelFreq = pandas.Series(yFreq / nObs, index = yCat, name = yName)

print('Frequency Table:\n',yCat, '\n', yFreq)
print('Relative Frequency Table:\n',yRelFreq)

# STEP 1: Train the classification tree

classTree = tree.DecisionTreeClassifier(criterion = 'entropy', max_depth = 6, random_state = None)
thisFit = classTree.fit(X_train, y_train)
print('Number of Leaves = ', classTree.tree_.node_count)
dot_data = tree.export_graphviz(classTree, out_file = None, impurity = True,
                                filled = True, proportion = False,
                                feature_names = xName, class_names = yCat)
graph = graphviz.Source(dot_data)

graph

# Convert to a dataframe
ppTrain_tree = pandas.DataFrame(thisFit.predict_proba(X_train), columns = yCat)
ppTest_tree = pandas.DataFrame(thisFit.predict_proba(X_test), columns = yCat)

# STEP 2: Train the logistic regression

designX = stats.add_constant(X_train, prepend = True)
logit = stats.MNLogit(y_train, designX)
thisFit = logit.fit(method='newton', maxiter = 100, gtol = 1e-6, full_output = True, disp = True)
print(thisFit.summary())

# Rename columns to correct names
ppTrain_logistic = thisFit.predict(designX).rename(columns={0:'Below', 1:'Match', 2:'Over'}) 

designX = stats.add_constant(X_test, prepend = True)
ppTest_logistic = thisFit.predict(designX).rename(columns={0:'Below', 1:'Match', 2:'Over'}) 

# STEP 3: Assess model for Training Partition
metric_tree, y_pred_tree, qMisClass_tree, obsAse_tree = NominalMetric(y = y_train, predProb = ppTrain_tree)
print('Classification Tree (Training):\n', metric_tree)

metric_logistic, y_pred_logistic, qMisClass_logistic, obsAse_logistic = NominalMetric(y = y_train, predProb = ppTrain_logistic)
print('Logistic Regression (Training):\n', metric_logistic)

# Confusion Matrix
xtab_tree = pandas.crosstab(y_train, y_pred_tree, normalize = 'index')
print('Confusion Matrix (Classification Tree, Training) :\n', xtab_tree)

xtab_logistic = pandas.crosstab(y_train, y_pred_logistic, normalize = 'index')
print('Confusion Matrix (Logistic Regression, Training) :\n', xtab_logistic)

# Misclassification Rate within category
misClassRate = pandas.DataFrame(index = yCat, columns = ['Tree', 'Logistic'])
for cat in yCat:
   t = numpy.mean(qMisClass_tree[y_train == cat])
   s = numpy.mean(qMisClass_logistic[y_train == cat])
   misClassRate.loc[cat,'Tree'] = t
   misClassRate.loc[cat,'Logistic'] = s

fig, ax = plt.subplots()
ax.plot(misClassRate.index, misClassRate['Tree'], 'go-', label = 'Classification Tree')
ax.plot(misClassRate.index, misClassRate['Logistic'], 'rs-', label = 'Logistic Regression')
ax.grid(b = True, which = 'major', axis = 'y')
ax.set_xlabel('')
ax.set_ylabel('Misclassification Rate')
plt.legend(title = 'Training Partition:')
plt.show()

# Average Squared Error
AveSqError = pandas.DataFrame(index = yCat, columns = ['Tree', 'Logistic'])
for cat in yCat:
   t = numpy.mean(obsAse_tree[y_train == cat])
   s = numpy.mean(obsAse_logistic[y_train == cat])
   AveSqError.loc[cat,'Tree'] = t
   AveSqError.loc[cat,'Logistic'] = s

fig, ax = plt.subplots()
ax.plot(AveSqError.index, AveSqError['Tree'], 'go-', label = 'Classification Tree')
ax.plot(AveSqError.index, AveSqError['Logistic'], 'rs-', label = 'Logistic Regression')
ax.grid(b = True, which = 'major', axis = 'y')
ax.set_xlabel('')
ax.set_ylabel('Average Squared Error')
plt.legend(title = 'Training Partition:')
plt.show()

# STEP 4: Assess model for Testing Partition
metric_tree, y_pred_tree, qMisClass_tree, obsAse_tree = NominalMetric(y = y_test, predProb = ppTest_tree)
print('Classification Tree (Testing):\n', metric_tree)

metric_logistic, y_pred_logistic, qMisClass_logistic, obsAse_logistic = NominalMetric(y = y_test, predProb = ppTest_logistic)
print('Logistic Regression (Testing):\n', metric_logistic)

# Confusion Matrix
xtab_tree = pandas.crosstab(y_test, y_pred_tree, normalize = 'index')
print('Confusion Matrix (Classification Tree, Testing) :\n', xtab_tree)

xtab_logistic = pandas.crosstab(y_test, y_pred_logistic, normalize = 'index')
print('Confusion Matrix (Logistic Regression, Testing) :\n', xtab_logistic)

# Misclassification Rate within category
misClassRate = pandas.DataFrame(index = yCat, columns = ['Tree', 'Logistic'])
for cat in yCat:
   select = numpy.array(y_test.index[y_test == cat], dtype = int)
   t = numpy.mean(qMisClass_tree[select])
   s = numpy.mean(qMisClass_logistic[select])
   misClassRate.loc[cat,'Tree'] = t
   misClassRate.loc[cat,'Logistic'] = s

fig, ax = plt.subplots()
ax.plot(misClassRate.index, misClassRate['Tree'], 'go-', label = 'Classification Tree')
ax.plot(misClassRate.index, misClassRate['Logistic'], 'rs-', label = 'Logistic Regression')
ax.grid(b = True, which = 'major', axis = 'y')
ax.set_xlabel('')
ax.set_ylabel('Misclassification Rate')
plt.legend(title = 'Testing Partition:')
plt.show()

# Average Squared Error
AveSqError = pandas.DataFrame(index = yCat, columns = ['Tree', 'Logistic'])
for cat in yCat:
   select = numpy.array(y_test.index[y_test == cat], dtype = int)
   t = numpy.mean(obsAse_tree[select])
   s = numpy.mean(obsAse_logistic[select])
   AveSqError.loc[cat,'Tree'] = t
   AveSqError.loc[cat,'Logistic'] = s

fig, ax = plt.subplots()
ax.plot(AveSqError.index, AveSqError['Tree'], 'go-', label = 'Classification Tree')
ax.plot(AveSqError.index, AveSqError['Logistic'], 'rs-', label = 'Logistic Regression')
ax.grid(b = True, which = 'major', axis = 'y')
ax.set_xlabel('')
ax.set_ylabel('Average Squared Error')
plt.legend(title = 'Testing Partition:')
plt.show()
