# Name: Ch4_Distance_From_Chicago.py
# Creation Date: April 6, 2020
# Author: Ming-Long Lam

import matplotlib.pyplot as plt
import numpy
import pandas

import sklearn.cluster as cluster
import sklearn.metrics as metrics

inputData = pandas.read_csv('C:\\Machine Learning Book\\Data\\distance_from_chicago.csv',
                            delimiter = ',', index_col = 'CityState')


# trainData must be a dataframe
trainData = inputData[['DrivingMilesFromChicago']]

# Explore the distribution of the distances
plt.hist(trainData['DrivingMilesFromChicago'], bins = numpy.arange(0,2200,50), align = 'mid')
plt.xticks(numpy.arange(0,2200,200))
plt.xlabel('Driving Distance from Chicago (Miles)')
plt.minorticks_on()
plt.grid(axis='both')
plt.show()

nCity = trainData.shape[0]
maxNClusters = 10

nClusters = numpy.zeros(maxNClusters)
Elbow = numpy.zeros(maxNClusters)
Silhouette = numpy.zeros(maxNClusters)
TotalWCV = numpy.zeros(maxNClusters)
Inertia = numpy.zeros(maxNClusters)

WCV = numpy.zeros(maxNClusters)
nC = numpy.zeros(maxNClusters)

# Loop over cluster solutions
for c in range(maxNClusters):
   KClusters = c + 1
   nClusters[c] = KClusters

   thisCluster = cluster.KMeans(n_clusters = KClusters, random_state = None).fit(trainData)

   # The Inertia value is the within cluster squared Euclidean distance from the centroid
   Inertia[c] = thisCluster.inertia_

   if (KClusters > 1):
       Silhouette[c] = metrics.silhouette_score(trainData, thisCluster.labels_)
   else:
       Silhouette[c] = numpy.nan

   WCV = numpy.zeros(KClusters)
   nC = numpy.zeros(KClusters)

   for i in range(nCity):
      k = thisCluster.labels_[i]
      nC[k] += 1
      diff = trainData.iloc[i,] - thisCluster.cluster_centers_[k]
      WCV[k] += diff.dot(diff)

   Elbow[c] = 0
   for k in range(KClusters):
      Elbow[c] += WCV[k] / nC[k]
      TotalWCV[c] += WCV[k]

print("N Clusters\t Inertia\t Total WCV\t Elbow Value\t Silhouette Value:")
for c in range(maxNClusters):
   print('{:.0f} \t {:.6f} \t {:.6f} \t {:.6f} \t {:.6f}'
         .format(nClusters[c], Inertia[c], TotalWCV[c], Elbow[c], Silhouette[c]))

plt.plot(nClusters, Elbow, linewidth = 2, marker = 'o')
plt.grid(True)
plt.xlabel("Number of Clusters")
plt.ylabel("Elbow Value")
plt.xticks(numpy.arange(1,(maxNClusters+1),1))
plt.show()

plt.plot(nClusters, Silhouette, linewidth = 2, marker = 'o')
plt.grid(True)
plt.xlabel("Number of Clusters")
plt.ylabel("Silhouette Index")
plt.xticks(numpy.arange(1,(maxNClusters+1),1))
plt.show()

# Get the Four Cluster Solution
KClusters = 4
thisCluster = cluster.KMeans(n_clusters = KClusters, random_state = None).fit(trainData)
print("Centroid = ", thisCluster.cluster_centers_)

trainData['Cluster'] = thisCluster.labels_

group_df = trainData.groupby('Cluster')

for key, item in group_df:
    print('Cluster = ', key, '\n')
    print('Number of Cities = ', len(item), '\n')
    print(item['DrivingMilesFromChicago'])
    print('\n\n')
    
