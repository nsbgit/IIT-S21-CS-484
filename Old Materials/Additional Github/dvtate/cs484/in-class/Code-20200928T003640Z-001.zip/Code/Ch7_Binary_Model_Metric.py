import numpy
import pandas

# Requirements:
#  1. The target Series must have the same length as the predProbEvent Series
#  2. Both Series cannot contain any missing values

def binary_model_evaluate (
   target,                   # Panda Series that contains values of target variable
   valueEvent,               # Formatted value of target variable that indicates an event
   valueNonEvent,            # Formatted value of target variable that indicates a non-event
   predProbEvent,            # Panda Series that contains predicted probability that the event will occur
   eventProbThreshold = 0.5  # Threshold for event probability to indicate a success
):

   # Separate the predicted probabilities according to the target values
   ppE_oE = predProbEvent[target == valueEvent]
   ppE_oNE = predProbEvent[target == valueNonEvent]

   n_pE_oE = len(ppE_oE)
   n_pE_oNE = len(ppE_oNE)
   n_pE = n_pE_oE + n_pE_oNE

   # Calculate the root average square error
   ase = (numpy.sum((1.0 - ppE_oE)**2) + numpy.sum((0.0 - ppE_oNE)**2)) / n_pE
   if (ase > 0.0):
      rase = numpy.sqrt(ase)
   else:
      rase = 0.0
    
   # Calculate the misclassification error rate
   nFN = numpy.count_nonzero(ppE_oE < eventProbThreshold)       # False Negative
   nFP = numpy.count_nonzero(ppE_oNE >= eventProbThreshold)     # False Positive
   mce = (nFP + nFN) / n_pE

   # Calculate the number of concordant, discordant, and tied pairs
   nConcordant = 0.0
   nDiscordant = 0.0
   nTied = 0.0

   # Loop over the predicted event probabilities from the Event column
   for eProb in ppE_oE:
      _thisC = numpy.count_nonzero(ppE_oNE < eProb)
      _thisD = numpy.count_nonzero(ppE_oNE > eProb)
      nConcordant = nConcordant + _thisC
      nDiscordant = nDiscordant + _thisD
      nTied = nTied + (n_pE_oNE - _thisC - _thisD)

   modelStat = pandas.Series({'NOBS': n_pE, 'ASE': ase, 'RASE': rase, 'NFP': nFP, 'NFN': nFN,
                              'MCE': mce, 'NCONCORDANT': nConcordant, 'NDISCORDANT': nDiscordant,
                              'NTIED': nTied})

   return(modelStat)

scoreData = pandas.DataFrame(
    {'Y': ['Event','Non-Event','Non-Event','Event', 'Event','Non-Event',
           'Event','Non-Event','Event','Event','Non-Event'],
     'predEP': [0.9,0.5,0.3,0.7,0.3,0.8,0.4,0.2,1,0.5,0.3]})

eventValue = 'Event'
nonEventValue = 'Non-Event'
eventProbThreshold = 0.5

modelStat = binary_model_metric(scoreData['Y'], 'Event', 'Non-Event', scoreData['predEP'])
print(modelStat)
