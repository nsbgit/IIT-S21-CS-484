# Name: Ch6_Binary_Model_Evaluate.py
# Creation Date: June 30, 2020
# Author: Ming-Long Lam

import matplotlib.pyplot as plt
import numpy
import pandas

# Requirements:
#  1. The target Series must have the same length as the predProbEvent Series
#  2. Both Series cannot contain any missing values

def binary_model_evaluate (
   target,                   # Panda Series that contains values of target variable
   valueEvent,               # Formatted value of target variable that indicates an event
   valueNonEvent,            # Formatted value of target variable that indicates a non-event
   predProbEvent,            # Panda Series that contains predicted probability that the event will occur
   eventProbThreshold = 0.5  # Threshold for event probability to indicate a success
):

   # Separate the predicted probabilities according to the target values
   ppE_oE, freq_pE_oE = numpy.unique(predProbEvent[target == valueEvent], return_counts = True)
   ppE_oNE, freq_pE_oNE = numpy.unique(predProbEvent[target == valueNonEvent], return_counts = True)

   n_pE_oE = numpy.sum(freq_pE_oE)
   n_pE_oNE = numpy.sum(freq_pE_oNE)
   n_pE = n_pE_oE + n_pE_oNE

   # Calculate the root average square error
   ase = (numpy.sum(freq_pE_oE * (1.0 - ppE_oE)**2) + numpy.sum(freq_pE_oNE * (0.0 - ppE_oNE)**2)) / n_pE
   if (ase > 0.0):
      rase = numpy.sqrt(ase)
   else:
      rase = 0.0

   # Calculate the misclassification error rate
   nFN = numpy.sum(freq_pE_oE[ppE_oE < eventProbThreshold])     # False Negative
   nFP = numpy.sum(freq_pE_oNE[ppE_oNE >= eventProbThreshold])  # False Positive
   mce = (nFP + nFN) / n_pE

   # Calculate the number of concordant, discordant, and tied pairs
   nConcordant = 0.0
   nDiscordant = 0.0
   nTied = 0.0

   # Loop over the predicted event probabilities from the Event column
   for eProb, eFreq in zip(ppE_oE, freq_pE_oE):
      _thisC = eFreq * numpy.sum(freq_pE_oNE[ppE_oNE < eProb])
      _thisD = eFreq * numpy.sum(freq_pE_oNE[ppE_oNE > eProb])
      nConcordant = nConcordant + _thisC
      nDiscordant = nDiscordant + _thisD
      nTied = nTied + (n_pE_oNE - _thisC - _thisD)

   # Calculate Area Under Curve and Gini Coefficient
   auc = 0.5 + 0.5 * (nConcordant - nDiscordant) / (nConcordant + nDiscordant + nTied)
   gini = auc + auc - 1.0

   # Calculate Goodman-Kruskal Gamma
   gk_gamma = (nConcordant - nDiscordant) / (nConcordant + nDiscordant)

   # Generate Receiver Operating Characteristic curve coordinates
   pThreshold = numpy.unique(numpy.concatenate((ppE_oE, ppE_oNE)))
   nThreshold = len(pThreshold)
   rocCoordinate = numpy.zeros(((nThreshold+2),3))
   prCoordinate = numpy.zeros(((nThreshold+1),4))
   ksThreshold = numpy.NaN
   ksStat = -1.0

   rocCoordinate[0:] = [numpy.NaN, 0.0, 0.0]               # Add dummy point (0,0)
   prCoordinate[0,:] = [numpy.NaN, 0.0, 1.0, numpy.NaN]    # Add dummy point (0,1)
   for i in range(nThreshold):
      thresh = pThreshold[nThreshold-i-1]
      nFN = numpy.sum(freq_pE_oE[ppE_oE < thresh])
      nFP = numpy.sum(freq_pE_oNE[ppE_oNE >= thresh])
      nTP = n_pE_oE - nFN
      sensitivity = 1.0 - (nFN / n_pE_oE)
      oneMinusSpecificity = nFP / n_pE_oNE
      precision = nTP / (nTP + nFP)
      f1Score =  1.0 / ((1.0 / precision + 1.0 / sensitivity) / 2.0)
      gapDistance = sensitivity - oneMinusSpecificity
      if (gapDistance > ksStat):
         ksThreshold = thresh
         ksStat = gapDistance

      rocCoordinate[i+1:] = [thresh, oneMinusSpecificity, sensitivity]
      prCoordinate[i+1,:] = [thresh, sensitivity, precision, f1Score]

   rocCoordinate[nThreshold+1:] = [numpy.NaN, 1.0, 1.0]    # Add dummy point (1,1)
      
   modelStat = pandas.Series({'NOBS': n_pE, 'ASE': ase, 'RASE': rase,
                              'NFP': nFP, 'NFN': nFN, 'MCE': mce, 
                              'NCONCORDANT': nConcordant, 'NDISCORDANT': nDiscordant, 'NTIED': nTied,
                              'AUC': auc, 'GINI': gini, 'GAMMA': gk_gamma,
                              'K-S': ksStat, 'K-S THRESHOLD': ksThreshold})

   return(modelStat, rocCoordinate, prCoordinate)

scoreData = pandas.DataFrame(
    {'Y': ['Event','Non-Event','Non-Event','Event', 'Event','Non-Event',
           'Event','Non-Event','Event','Event','Non-Event'],
     'predEP': [0.9,0.5,0.3,0.7,0.3,0.8,0.4,0.2,1,0.5,0.3]})

eventValue = 'Event'
nonEventValue = 'Non-Event'
eventProbThreshold = 0.5

modelStat, rocCoordinate, prCoordinate = binary_model_roc(scoreData['Y'], 'Event', 'Non-Event', scoreData['predEP'])
print(modelStat)
print(rocCoordinate)
print(prCoordinate)

plt.plot(rocCoordinate[:,1], rocCoordinate[:,2], 'bo-')
plt.xticks(numpy.arange(0,1.1,0.1))
plt.yticks(numpy.arange(0,1.1,0.1))
plt.xlabel('1 - Specificity')
plt.ylabel('Sensitivity')
plt.grid(axis="both")
plt.show()

plt.plot(rocCoordinate[:,0], rocCoordinate[:,1], 'go-', label = 'False Positive')
plt.plot(rocCoordinate[:,0], rocCoordinate[:,2], 'rs-', label = 'True Positive')
plt.xticks(numpy.arange(0,1.1,0.1))
plt.yticks(numpy.arange(0,1.1,0.1))
plt.ylabel('Positive Rate')
plt.xlabel('Threshold')
plt.grid(axis="both")
plt.show()

noSkill = numpy.count_nonzero(scoreData['Y'] == eventValue) / len(scoreData['Y'])
plt.plot(prCoordinate[:,1], prCoordinate[:,2], 'bo-')
plt.hlines(noSkill, 0.0, 1.0, colors = 'red', linestyles = 'dashed', label = 'No Skill')
plt.xticks(numpy.arange(0,1.1,0.1))
plt.yticks(numpy.arange(0,1.1,0.1))
plt.xlabel('Recall')
plt.ylabel('Precision')
plt.grid(axis="both")
plt.show()

plt.plot(prCoordinate[:,0], prCoordinate[:,3], 'bo-')
plt.xticks(numpy.arange(0,1.1,0.1))
plt.xlabel('Threshold')
plt.ylabel('F1 Score')
plt.grid(axis="both")
plt.show()
