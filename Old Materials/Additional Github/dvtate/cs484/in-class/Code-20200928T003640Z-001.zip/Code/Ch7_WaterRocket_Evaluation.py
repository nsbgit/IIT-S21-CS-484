# Name: Ch7_WaterRocket_Evaluation.py
# Creation Date: June 15, 2020
# Author: Ming-Long Lam

import numpy
import pandas
import pickle
import statsmodels.api as stats

pandas.set_option('precision', 7)

# Requirements:
#  1. The target Series must have the same length as the predProbEvent Series
#  2. Both Series cannot contain any missing values

def binary_model_metric (
   target,                   # Panda Series that contains values of target variable
   valueEvent,               # Formatted value of target variable that indicates an event
   valueNonEvent,            # Formatted value of target variable that indicates a non-event
   predProbEvent,            # Panda Series that contains predicted probability that the event will occur
   eventProbThreshold = 0.5  # Threshold for event probability to indicate a success
):

   # Number of observations
   nObs = len(target)

   # Aggregate observations by the target values and the predicted probabilities
   aggrProb = pandas.crosstab(predProbEvent, target, dropna = True)

   # Calculate the root average square error
   ase = (numpy.sum(aggrProb[valueEvent] * (1.0 - aggrProb.index)**2) + 
          numpy.sum(aggrProb[valueNonEvent] * (0.0 - aggrProb.index)**2)) / nObs
   if (ase > 0.0):
      rase = numpy.sqrt(ase)
   else:
      rase = 0.0
    
   # Calculate the misclassification error rate
   nFP = numpy.sum(aggrProb[valueEvent].iloc[aggrProb.index < eventProbThreshold])
   nFN = numpy.sum(aggrProb[valueNonEvent].iloc[aggrProb.index >= eventProbThreshold])
   mce = (nFP + nFN) / nObs

   # Calculate the number of concordant, discordant, and tied pairs
   nConcordant = 0.0
   nDiscordant = 0.0
   nTied = 0.0

   # Loop over the predicted event probabilities from the Event column
   predEP = aggrProb.index
   eventFreq = aggrProb[valueEvent]

   for i in range(len(predEP)):
      eProb = predEP[i]
      eFreq = eventFreq.loc[eProb]
      if (eFreq > 0.0):
         nConcordant = nConcordant + numpy.sum(eFreq * aggrProb[valueNonEvent].iloc[eProb > aggrProb.index])
         nDiscordant = nDiscordant + numpy.sum(eFreq * aggrProb[valueNonEvent].iloc[eProb < aggrProb.index])
         nTied = nTied + numpy.sum(eFreq * aggrProb[valueNonEvent].iloc[eProb == aggrProb.index])
         
   auc = 0.5 + 0.5 * (nConcordant - nDiscordant) / (nConcordant + nDiscordant + nTied)
   gini = 2.0 * auc - 1.0
   gamma = (nConcordant - nDiscordant) / (nConcordant + nDiscordant)

   outSeries = pandas.Series({'NOBS': nObs, 'ASE': ase, 'RASE': rase,
                              'NFP': nFP, 'NFN': nFN,
                              'MCE': mce, 'AUC': auc, 'GINI': gini, 'GAMMA': gamma,
                              'NCONCORDANT': nConcordant,
                              'NDISCORDANT': nDiscordant,
                              'NTIED': nTied})
   return(outSeries)

yName = 'Reached Ceiling'
xName = ['Initial Amount of Water (Kg)', 'Initial Pressure (atm)']

# STEP 1: Read the training partition

inputData = pandas.read_table('C:\\Machine Learning Book\\Data\\WaterRocket.txt',
                              delimiter = ',', header = None,
                              names = xName + ['Maximum_Height'])

inputData[yName] = numpy.where(inputData['Maximum_Height'] >= 15.0, 'Yes', 'No')
X_train = inputData[xName]
y_train = inputData[yName]

# STEP 2: Get the Decision Tree model pickle and score the model
with (open('C:\\Machine Learning Book\\Code\\WaterRocketClassTree.pickle', 'rb')) as _pFile:
   classTree = pickle.load(_pFile)

pProbClassTree = classTree.predict_proba(X_train)

metricClassTree = binary_model_metric (
   target = y_train,
   valueEvent = 'Yes',
   valueNonEvent = 'No',
   predProbEvent = pProbClassTree[:,1],
   eventProbThreshold = 0.5)

# STEP 2a: Get the Logistic Regression model pickle
with (open('C:\\Machine Learning Book\\Code\\WaterRocketMNLogistic.pickle', 'rb')) as _pFile:
   logReg = pickle.load(_pFile)

designX = X_train
designX = stats.add_constant(designX, prepend = True)

pProbLogReg = logReg.predict(designX).rename(columns = {0: 'No', 1: 'Yes'})

metricLogReg = binary_model_metric (
   target = y_train,
   valueEvent = 'Yes',
   valueNonEvent = 'No',
   predProbEvent = pProbLogReg['Yes'],
   eventProbThreshold = 0.5)


