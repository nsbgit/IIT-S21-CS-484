# Name: Ch7_OverTrained_Tree.py
# Creation Date: June 3, 2020
# Author: Ming-Long Lam

import numpy
import random

import graphviz
import sklearn.tree as tree

n = 10

X_train = numpy.zeros((n,1))
y_train = numpy.zeros((n,1))

random.seed(27513)

for i in range(n):
    X_train[i,0] = random.uniform(-1.0, 1.0)
    y_train[i,0] = numpy.where(i % 3 == 0, 1, 0)

classTree = tree.DecisionTreeClassifier(criterion = 'entropy', max_depth = 10, random_state = None)

thisFit = classTree.fit(X_train, y_train)

dot_data = tree.export_graphviz(classTree, out_file = None, impurity = True,
                                filled = True, proportion = False,
                                feature_names = ['x'], class_names = ['0', '1'])

graph = graphviz.Source(dot_data)

graph

graph.render('C:\\Machine Learning Book\\Image\\Ch6_WaterRocket_Tree', format = 'png')
