# Name: Ch8_RandomRectangle_Compare.py
# Creation Date: June 30, 2020
# Author: Ming-Long Lam

import matplotlib.pyplot as plt
import numpy
import pandas
import graphviz

from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import KBinsDiscretizer 
from sklearn.tree import DecisionTreeRegressor, export_graphviz

pandas.set_option('precision', 7)

# Read the random rectangle data
yName = 'area'
xName = ['perimeter']

inputData = pandas.read_table('C:\\Machine Learning Book\\Data\\RandomRectangle.csv',
                              delimiter = ',', header = 0,
                              usecols = xName + [yName])

X_train = inputData[xName]
y_train = inputData[yName]

# STEP 1: Explore the data

# Draw scatterplots for each pair of interval target and interval predictor
ivar = xName[0]
plt.scatter(X_train[ivar], y_train, c = 'blue', marker = 'o', s = 4)
plt.xlabel(ivar)
plt.ylabel(yName)
plt.grid(axis="both")
plt.show()

# STEP 2: Train a linear regression model

linReg = LinearRegression(fit_intercept = False)
thisReg = linReg.fit(X_train, y_train)
 
print('Coefficients: ', thisReg.coef_)

p_y_reg = thisReg.predict(X_train)
ssqres_y_reg = (p_y_reg - y_train) ** 2

plt.scatter(y_train, p_y_reg, c = 'blue', marker = 'o', s = 4)
plt.title('Linear Regression')
plt.xticks(numpy.arange(0,11000,1000))
plt.yticks(numpy.arange(0,11000,1000))
plt.xlabel('Observed ' + str(yName))
plt.ylabel('Predicted ' + str(yName))
plt.grid(axis="both")
plt.show()

# STEP 3: Train the regression tree

regTree = DecisionTreeRegressor(criterion = 'mse', splitter = 'best', max_depth = 3, random_state = None)
thisTree = regTree.fit(X_train, y_train)

dot_data = export_graphviz(regTree, out_file = None, impurity = True,filled = True, feature_names = xName)
graph = graphviz.Source(dot_data)

graph

p_y_tree = thisTree.predict(X_train)
ssqres_y_tree = (p_y_tree - y_train) ** 2

plt.scatter(y_train, p_y_tree, c = 'blue', marker = 'o', s = 4)
plt.title('Regression Tree')
plt.xticks(numpy.arange(0,11000,1000))
plt.yticks(numpy.arange(0,11000,1000))
plt.xlabel('Observed ' + str(yName))
plt.ylabel('Predicted ' + str(yName))
plt.grid(axis="both")
plt.show()

# STEP 4: Calculate the RMSE, the Relative Error, and the R Squared metrics
def IntervalMetric (y, py):
   
   n = len(y)                     # Number of observations

   # Root Mean Squared Error
   ssq_error = numpy.sum((y - py) ** 2)
   rmse = numpy.sqrt(ssq_error / n)

   # Relative Error
   mean_y = numpy.mean(y)
   ssq_y = numpy.sum((y - mean_y) ** 2)
   relerr = ssq_error / ssq_y

   # R-Squared
   mean_py = numpy.mean(py)
   ssq_py = numpy.sum((py - mean_py) ** 2)
   cssq_y_py = numpy.sum((y - mean_y) * (py - mean_py))
   rsq = (cssq_y_py / ssq_y) * (cssq_y_py / ssq_py)

   outMetric = pandas.Series({'RMSQ': rmse,
                              'RELERR': relerr,
                              'RSQ': rsq})
   return (outMetric)

outNMetric4LR = IntervalMetric(y_train, p_y_reg)

outNMetric4RT = IntervalMetric(y_train, p_y_tree)

# STEP 5: Compare RMSE by Deciles of Observed Target Variable

# Create the decile indicators
binning = KBinsDiscretizer(n_bins = 10, encode = 'ordinal', strategy = 'quantile')
decile_y = binning.fit_transform(y_train.values.reshape(-1,1))

# Assemble the arrays and Series into a dataframe for easier manipulation
df4Compare = pandas.concat([pandas.DataFrame(decile_y, columns = ['decile_y']),
                            y_train.rename('y_train'),
                            ssqres_y_tree.rename('ssqres_y_tree'),
                            ssqres_y_reg.rename('ssqres_y_reg')], axis = 1)

# Generate boxplots of target values by decile
df4Compare.boxplot(column = 'y_train', by = 'decile_y', vert = True)
plt.title('')
plt.suptitle('')
plt.xlabel('Decile in Ascending ' + yName)
plt.ylabel(yName)
plt.grid(axis = 'x')
plt.show()

# Boundary of Trip_Time in deciles
decile_upper = df4Compare[['decile_y','y_train']].groupby('decile_y').max().values
print('Decile Upper Boundary:\n', decile_upper)

# Number of observations in deciles
decile_count = df4Compare[['decile_y']].groupby('decile_y').size().to_frame(name = 'y_train')

# Mean squared error in deciles
MSQ_res_tree = df4Compare[['decile_y','ssqres_y_tree']].groupby('decile_y').mean().values
MSQ_res_reg = df4Compare[['decile_y','ssqres_y_reg']].groupby('decile_y').mean().values

# Root mean squared error in deciles
rmse_tree = numpy.sqrt(MSQ_res_tree)
rmse_reg = numpy.sqrt(MSQ_res_reg)

plt.plot(range(10), rmse_reg, 'bo-', label = 'Linear Regression')
plt.plot(range(10), rmse_tree, 'rs-', label = 'Regression Tree')
plt.xticks(range(10))
plt.xlabel('Decile in Ascending ' + yName)
plt.ylabel('Root Mean Squared Error')
plt.grid(axis = 'both')
plt.legend(title = 'Algorithm:')
plt.show()

# Corrected mean squared deviation from mean in deciles
CSSQ_y = ((decile_count - 1) / decile_count) * df4Compare[['decile_y','y_train']].groupby('decile_y').var()
relerr_tree = MSQ_res_tree / CSSQ_y.values
relerr_reg = MSQ_res_reg / CSSQ_y.values

plt.plot(range(10), relerr_reg, 'bo-', label = 'Linear Regression')
plt.plot(range(10), relerr_tree, 'rs-', label = 'Regression Tree')
plt.xticks(range(10))
plt.xlabel('Decile in Ascending ' + yName)
plt.ylabel('Relative Error')
plt.grid(axis = 'both')
plt.legend(title = 'Algorithm:')
plt.show()
