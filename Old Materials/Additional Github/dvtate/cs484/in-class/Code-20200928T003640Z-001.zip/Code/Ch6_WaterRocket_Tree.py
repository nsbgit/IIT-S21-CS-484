# Name: Ch6_WaterRocket_Tree.py
# Creation Date: June 10, 2020
# Author: Ming-Long Lam

import matplotlib.pyplot as plt
import numpy
import pandas
import pickle

import graphviz
import sklearn.tree as tree

pandas.set_option('precision', 7)

yName = 'Reached Ceiling'
xName = ['Initial Amount of Water (Kg)', 'Initial Pressure (atm)']

inputData = pandas.read_table('C:\\Machine Learning Book\\Data\\WaterRocket.txt',
                              delimiter = ',', header = None,
                              names = xName + ['Maximum_Height'])

inputData[yName] = numpy.where(inputData['Maximum_Height'] >= 15.0, 'Yes', 'No')

# STEP 1: Explore the data

# See the distribution of the target variable
print(inputData.groupby(yName).size())

# Draw boxplots of the interval predictors by levels of the target variable
for ivar in xName:
   inputData.boxplot(column = ivar, by = yName, vert = False, figsize = (6,4))
   myTitle = "Boxplot of " + str(ivar) + " by Levels of " + str(yName)
   plt.title(myTitle)
   plt.suptitle("")
   plt.xlabel(ivar)
   plt.ylabel(yName)
   plt.grid(axis="y")
   plt.show()

# STEP 2: Train the classification tree

X_train = inputData[xName]

y_train = inputData[yName]

classTree = tree.DecisionTreeClassifier(criterion = 'gini', max_depth = 5, random_state = None)

thisFit = classTree.fit(X_train, y_train)

# STEP 3: Visualize the classification tree

dot_data = tree.export_graphviz(classTree, out_file = None, impurity = True,
                                filled = True, proportion = False,
                                feature_names = xName, class_names = ['No', 'Yes'])

graph = graphviz.Source(dot_data)

graph

graph.render('C:\\Machine Learning Book\\Image\\Ch6_WaterRocket_Tree', format = 'png')

# STEP 3: Write the classification tree model as a Pickle object to an external file

with (open('C:\\Machine Learning Book\\Code\\WaterRocketClassTree.pickle', 'wb')) as pFile:
   pickle.dump(thisFit, pFile)
