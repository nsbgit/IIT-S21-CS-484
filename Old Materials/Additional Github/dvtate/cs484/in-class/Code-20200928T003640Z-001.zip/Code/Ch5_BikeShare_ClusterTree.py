# Name: Ch5_BikeShare_ClusterTree.py
# Creation Date: May 6, 2020
# Author: Ming-Long Lam

# Load the necessary libraries
import matplotlib.pyplot as plt
import numpy
import pandas

import graphviz
import sklearn.cluster as cluster
import sklearn.metrics as metrics
import sklearn.tree as tree

pandas.set_option('precision', 7)

bikeshare = pandas.read_csv('C:\\Machine Learning Book\\Data\\bike_sharing_demand_train.csv',
                            delimiter=',')

# Use only these three interval variables
trainData = bikeshare[['temp', 'humidity', 'windspeed']].dropna()
nObs = trainData.shape[0]

# Determine number of clusters using Elbow values and Silhouette indices
maxNClusters = 10
nClusters = numpy.zeros(maxNClusters)
Elbow = numpy.zeros(maxNClusters)
Silhouette = numpy.zeros(maxNClusters)

for c in range(maxNClusters):
   KClusters = c + 1
   nClusters[c] = KClusters

   kmeans = cluster.KMeans(n_clusters = KClusters, random_state = None).fit(trainData)

   if (KClusters > 1):
       Silhouette[c] = metrics.silhouette_score(trainData, kmeans.labels_)
   else:
       Silhouette[c] = numpy.nan

   nC = numpy.zeros(KClusters)
   WCSS = numpy.zeros(KClusters)

   for i in range(nObs):
      k = kmeans.labels_[i]
      nC[k] += 1
      diff = trainData.iloc[i,] - kmeans.cluster_centers_[k]
      WCSS[k] += diff.dot(diff)

   Elbow[c] = 0
   for k in range(KClusters):
      Elbow[c] += WCSS[k] / nC[k]

print('\nSize \tElbow Value \tSilhouette Value\n')
for c in range(maxNClusters):
   print(nClusters[c], '\t', Elbow[c], '\t', Silhouette[c])

plt.plot(nClusters, Elbow, linewidth = 2, marker = 'o')
plt.xticks(range(1,maxNClusters,1))
plt.grid(True)
plt.xlabel('Number of Clusters')
plt.ylabel('Elbow Value')
plt.show()

plt.plot(nClusters, Silhouette, linewidth = 2, marker = 'o')
plt.xticks(range(1,maxNClusters,1))
plt.grid(True)
plt.xlabel('Number of Clusters')
plt.ylabel('Silhouette Index')
plt.show()

# Consider the two-cluster solution
KClusters = 2
kmeans = cluster.KMeans(n_clusters = KClusters, random_state = None, verbose = 1).fit(trainData)

nC = numpy.zeros(KClusters)
for i in range(nObs):
   k = kmeans.labels_[i]
   nC[k] += 1

for k in range(KClusters):
   print('\n Cluster = ', k)
   print('    Size = ', nC[k])
   print('Centroid = ', kmeans.cluster_centers_[k])

# Train a decision tree of depth of four using Gini Index
classTree = tree.DecisionTreeClassifier(criterion = 'gini', max_depth = 4, random_state = None)

bikeshare_DT = classTree.fit(trainData, kmeans.labels_)
print('Accuracy of Decision Tree classifier on training set = {:.7f}' .format(classTree.score(trainData, kmeans.labels_)))

dot_data = tree.export_graphviz(bikeshare_DT, out_file = None, impurity = True, filled = True,
                                feature_names = ['temp', 'humidity', 'windspeed'],
                                class_names = ['Cluster 0', 'Cluster 1'])

dt_rule = tree.export_text(bikeshare_DT, feature_names = ['temp', 'humidity', 'windspeed'],
                           max_depth = 4, spacing = 3, decimals = 3, show_weights = True)

with open('C:\\Machine Learning Book\\Image\\Ch5_bikeshare_clustertree_rule.txt', 'w') as outfile:
    outfile.write(dt_rule)
    
graph = graphviz.Source(dot_data)

fig= plt.figure(figsize=(12,9), dpi = 1200)
graph

graph.render('C:\\Machine Learning Book\\Image\\Ch5_bikeshare_clustertree', format = 'png', view = True)
