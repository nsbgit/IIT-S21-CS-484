# Name: Ch6_SweepOperator.py
# Creation Date: May 24, 2020
# Author: Ming-Long Lam

import numpy

def SWEEPOperator (pDim, inputM, tol):
    # pDim: dimension of matrix inputM, integer greater than one
    # inputM: a square and symmetric matrix, numpy array
    # tol: singularity tolerance, positive real

    aliasParam = []
    nonAliasParam = []
    A = numpy.array(inputM, copy = True, dtype = numpy.float)
    diagA = numpy.diagonal(A)
    
    for k in range(pDim):
        akk = A[k,k]
        if (akk >= (tol * diagA[k])):
            nonAliasParam.append(k)
            for i in range(pDim):
                if (i != k):
                    for j in range(pDim):
                        if (j != k):
                            A[i,j] = A[i,j] - A[i,k] * (A[k,j] / akk)
                            A[j,i] = A[i,j]
                    A[i,k] = A[i,k] / akk
                    A[k,i] = A[i,k]
            A[k,k] = - 1.0 / akk
        else:
            aliasParam.append(k)
            for i in range(pDim):
                A[i,k] = 0.0
                A[k,i] = 0.0
    return A, aliasParam, nonAliasParam

A = numpy.array([[10,0,0], [0,20,0], [0,0,40]])
p = A.shape[0]
tol = 1.0e-7

invA, aliasParam, nonAliasParam = SWEEPOperator(p, A, tol)
print('Negative Generalized Inverse of A:\n', invA)
print('Aliased Parameters: ', aliasParam)
print('Non-Aliased Parameters: ', nonAliasParam)

A = numpy.array([[6,12,0], [12,28,0], [0,0,6]])
p = A.shape[0]
tol = 1.0e-7

invA, aliasParam, nonAliasParam = SWEEPOperator(p, A, tol)
print('Negative Generalized Inverse of A:\n', invA)
print('Aliased Parameters: ', aliasParam)
print('Non-Aliased Parameters: ', nonAliasParam)

X = numpy.array([[1,1,0,0,1,0,0,0],
                 [1,1,0,0,0,1,0,0],
                 [1,1,0,0,0,0,1,0],
                 [1,1,0,0,0,0,0,1],
                 [1,0,1,0,1,0,0,0],
                 [1,0,1,0,0,1,0,0],
                 [1,0,1,0,0,0,1,0],
                 [1,0,1,0,0,0,0,1],
                 [1,0,0,1,1,0,0,0],
                 [1,0,0,1,0,1,0,0],
                 [1,0,0,1,0,0,1,0],
                 [1,0,0,1,0,0,0,1]])

XtX = numpy.transpose(X).dot(X)

p = XtX.shape[0]
tol = 1.0e-7

invXtX, aliasParam, nonAliasParam = SWEEPOperator(p, XtX, tol)
print('Negative Generalized Inverse of XtX:\n', invXtX)
print('Aliased Parameters: ', aliasParam)
print('Non-Aliased Parameters: ', nonAliasParam)

X = numpy.array([[1, 1, 0, 0, 1, 0],        # The Table 6.4
                 [1, 0, 1, 0, 1, 0],
                 [1, 0, 1, 0, 0, 1],
                 [1, 0, 0, 1, 1, 0],
                 [1, 0, 0, 1, 0, 1]])
XtX = numpy.transpose(X).dot(X)             # The SSCP matrix
p = XtX.shape[0]
tol = 1.0e-7

invXtX, aliasParam, nonAliasParam = SWEEPOperator(p, XtX, tol)
print('Negative Generalized Inverse of XtX:\n', invXtX)
print('Aliased Parameters: ', aliasParam)
print('Non-Aliased Parameters: ', nonAliasParam)
