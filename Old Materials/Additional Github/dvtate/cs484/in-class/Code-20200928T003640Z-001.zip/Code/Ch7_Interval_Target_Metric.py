# Name: Ch6_Interval_Target_Metric.py
# Creation Date: June 15, 2020
# Author: Ming-Long Lam

import numpy
import pandas

scoreData = pandas.DataFrame({'Y': [38.85, 12.95, 11.01, 12.95, 12.95, 12.95, 12.95, 12.95, 12.95, 38.85, 25.9, 38.85, 38.85, 20.72, 38.85, 38.85, 10.36, 10.36, 38.85, 31.08],
                              'P_Y': [26.3247, 24.0096, 24.0096, 29.1937, 26.3247, 23.8424, 31.6253, 24.5104, 26.6372, 25.4954, 22.0002, 27.0709, 21.4263, 23.1692, 26.9466, 27.4986, 19.4294, 19.4294, 23.7639, 29.8697]})

# Inputs:
# y: a Pandas Series that contains the observed target values
# py: a Pandas Series that contains the predicted target values
#
# Output:
# outMetric: a Pandas Series that contains the metric values
#            RMSE = Root Mean Squared Error
#            RELERR = Relative Error
#            RSQ = R-Squared coefficient

def IntervalMetric (y, py):
   
   n = len(y)                     # Number of observations

   # Root Mean Squared Error
   ssq_error = numpy.sum((y - py) ** 2)
   rmse = numpy.sqrt(ssq_error / n)

   # Relative Error
   mean_y = numpy.mean(y)
   ssq_y = numpy.sum((y - mean_y) ** 2)
   relerr = ssq_error / ssq_y

   # R-Squared
   mean_py = numpy.mean(py)
   ssq_py = numpy.sum((py - mean_py) ** 2)
   cssq_y_py = numpy.sum((y - mean_y) * (py - mean_py))
   rsq = (cssq_y_py / ssq_y) * (cssq_y_py / ssq_py)

   outMetric = pandas.Series({'RMSQ': rmse,
                              'RELERR': relerr,
                              'RSQ': rsq})
   return (outMetric)

# Calculate the metrics for the entire data
outMetric = IntervalMetric(y = scoreData['Y'], py = scoreData['P_Y'])
