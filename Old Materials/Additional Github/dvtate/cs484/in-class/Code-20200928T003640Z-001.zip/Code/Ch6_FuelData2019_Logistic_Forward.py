# Name: Ch6_FuelData2019_Logistic_Forward.py
# Creation Date: May 25, 2020
# Author: Ming-Long Lam

import matplotlib.pyplot as plt
import numpy
import pandas
import scipy
import statsmodels.api as stats

from matplotlib.ticker import (MultipleLocator, FormatStrFormatter, AutoMinorLocator)

# Set some options for printing all the columns
pandas.set_option('precision', 7)

inputData = pandas.read_csv('C:\\Machine Learning Book\\Data\\fueleconomy_2019_datafile.csv',
                            delimiter = ',', header = 0)

trainData = inputData[['Drive Desc', 'Air Aspiration Method Desc', 'Unique Label?', 'Eng Displ']].dropna()

# Rename the columns
trainData = trainData.rename(columns={'Drive Desc': 'Drive Train',
                                      'Air Aspiration Method Desc': 'Air Aspiration Method',
                                      'Unique Label?': 'Is Unique Label',
                                      'Eng Displ': 'Engine Displacement'})

yName = 'Drive Train'
catName = ['Air Aspiration Method', 'Is Unique Label']
intName = ['Engine Displacement']

# Frequency of the categorical fields
print('\n--- Frequency of ' + yName + ' ---')
print(trainData[yName].value_counts())

for thisName in catName:
    print('\n--- Frequency of ' + thisName + ' ---')
    print(trainData[thisName].value_counts())

# Descriptive statistics of the interval field
for thisName in intName:
    print('\n--- Descriptive Statistics of ' + thisName + ' ---')
    print(trainData[intName].describe())

# Specify the color sequence
cmap = ['indianred','sandybrown','royalblue', 'olivedrab','purple']

# Generate the contingency table of the categorical input feature by the target
for thisName in catName:
    cntTable = pandas.crosstab(index = trainData[thisName], columns = trainData[yName],
                               margins = False, dropna = True)

    # Calculate the row percents
    pctTable = 100.0 * cntTable.div(cntTable.sum(1), axis = 'index')

    # Generate a horizontal stacked percentage bar chart
    barThick = 0.8
    yCat = cntTable.columns
    accPct = numpy.zeros(pctTable.shape[0])
    fig, ax = plt.subplots()
    for j in range(len(yCat)):
        catLabel = yCat[j]
        plt.barh(pctTable.index, pctTable[catLabel], color = cmap[j], left = accPct, label = catLabel,
                 height = barThick)
        accPct = accPct + pctTable[catLabel]
    ax.xaxis.set_major_locator(MultipleLocator(base = 20))
    ax.xaxis.set_major_formatter(FormatStrFormatter('%.0f%%'))
    ax.xaxis.set_minor_locator(MultipleLocator(base = 5))
    ax.set_xlabel('Percent')
    ax.set_ylabel(thisName)
    plt.grid(axis = 'x')
    plt.legend(loc = 'lower center', bbox_to_anchor = (0.35, 1), ncol = 3)
    plt.show()

# Generate the contingency table of the interval input feature by the target
for thisName in intName:
    cntTable = pandas.crosstab(index = trainData[thisName], columns = trainData[yName],
                               margins = False, dropna = True)

    # Calculate the row percents
    pctTable = 100.0 * cntTable.div(cntTable.sum(1), axis = 'index')
    yCat = cntTable.columns
    fig, ax = plt.subplots()
    plt.stackplot(pctTable.index, numpy.transpose(pctTable), baseline = 'zero', colors = cmap, labels = yCat)
    ax.xaxis.set_major_locator(MultipleLocator(base = 1))
    ax.xaxis.set_minor_locator(MultipleLocator(base = 0.5))
    ax.yaxis.set_major_locator(MultipleLocator(base = 20))
    ax.yaxis.set_major_formatter(FormatStrFormatter('%.0f%%'))
    ax.yaxis.set_minor_locator(MultipleLocator(base = 5))
    ax.set_xlabel(thisName)
    ax.set_ylabel('Percent')
    plt.grid(axis = 'both')
    plt.legend(loc = 'lower center', bbox_to_anchor = (0.5, 1), ncol = 2)
    plt.show()

# Create a cross-tabulation of xName by yName
thisIndex = []
for thisName in catName+intName:
    thisIndex.append(trainData[thisName])

crossTab = pandas.crosstab(index = thisIndex,
                           columns = trainData[yName], margins = True, margins_name = 'Total', dropna = True)

# The SWEEP Operator
def SWEEPOperator (pDim, inputM, tol):
    # pDim: dimension of matrix inputM, positive integer
    # inputM: a square and symmetric matrix, numpy array
    # tol: singularity tolerance, positive real

    aliasParam = []
    nonAliasParam = []
    A = numpy.array(inputM, copy = True, dtype = numpy.float)
    diagA = numpy.diagonal(A)
 
    for k in range(pDim):
        akk = A[k,k]
        if (akk >= (tol * diagA[k])):
            nonAliasParam.append(k)
            for i in range(pDim):
                if (i != k):
                    for j in range(pDim):
                        if (j != k):
                            A[i,j] = A[i,j] - A[i,k] * (A[k,j] / akk)
                            A[j,i] = A[i,j]
                    A[i,k] = A[i,k] / akk
                    A[k,i] = A[i,k]
            A[k,k] = - 1.0 / akk
        else:
            aliasParam.append(k)
            for i in range(pDim):
                A[i,k] = 0.0
                A[k,i] = 0.0
    return A, aliasParam, nonAliasParam

# A function that find the non-aliased columns, fit a logistic model, and return the full parameter estimates
def build_mnlogit (fullX, y):

    # Find the non-redundant columns in the design matrix fullX
    nFullParam = fullX.shape[1]
    XtX = numpy.transpose(fullX).dot(fullX)
    invXtX, aliasParam, nonAliasParam = SWEEPOperator(pDim = nFullParam, inputM = XtX, tol = 1e-13)

    # Build a multinomial logistic model
    X = fullX.iloc[:, list(nonAliasParam)]
    logit = stats.MNLogit(y, X)
    thisFit = logit.fit(method='ncg', maxiter = 1000, gtol = 1e-6,  
                        full_output = True, disp = True)
    thisParameter = thisFit.params
    thisLLK = logit.loglike(thisParameter.values)
    
    # The number of free parameters
    y_category = y.cat.categories
    nYCat = len(y_category)
    thisDF = len(nonAliasParam) * (nYCat - 1)

    # Return model statistics
    return (thisLLK, thisDF, thisParameter, thisFit)

# Reorder the categories in ascending order of frequencies
# Create dummy indicators for the categorical input feature
xCat = []
for thisName in catName:
    catFreq = trainData[thisName].value_counts()
    catFreq = catFreq.sort_values(ascending = True)
    newCat = catFreq.index
    u = trainData[thisName].astype('category')
    xCat.append(pandas.get_dummies(u.cat.reorder_categories(newCat)))

# Column for the interval input feature
xInt = trainData[intName]

# Reorder the categories in descending order of frequencies of the target field
catFreq = trainData[yName].value_counts()
catFreq = catFreq.sort_values(ascending = False)
newCat = catFreq.index
u = trainData[yName].astype('category')
y = u.cat.reorder_categories(newCat)
print('Target Categories:\n', y.cat.categories)

# Train a Logistic Regression model using the Forward Selection method
devianceTable = pandas.DataFrame()

u = pandas.DataFrame()

# Step 0: Intercept only model
u = y.isnull()
designX = pandas.DataFrame(u.where(u, 1)).rename(columns = {yName: "const"})
LLK0, DF0, fullParams0, thisFit = build_mnlogit (designX, y)
devianceTable = devianceTable.append([[0, 'Intercept', DF0, LLK0, None, None, None]])

# Step 1.1: Intercept + 'Air Aspiration Method'
designX = xCat[0]
designX = stats.add_constant(designX, prepend = True)
LLK1, DF1, fullParams1, thisFit = build_mnlogit (designX, y)
testDev = 2.0 * (LLK1 - LLK0)
testDF = DF1 - DF0
testPValue = scipy.stats.chi2.sf(testDev, testDF)
devianceTable = devianceTable.append([[1.1, 'Intercept + Air Aspiration Method',
                                       DF1, LLK1, testDev, testDF, testPValue]])

# Step 1.2: Intercept + 'Is Unique Label'
designX = xCat[1]
designX = stats.add_constant(designX, prepend = True)
LLK1, DF1, fullParams1, thisFit = build_mnlogit (designX, y)
testDev = 2.0 * (LLK1 - LLK0)
testDF = DF1 - DF0
testPValue = scipy.stats.chi2.sf(testDev, testDF)
devianceTable = devianceTable.append([[1.2, 'Intercept + Is Unique Label',
                                       DF1, LLK1, testDev, testDF, testPValue]])

# Step 1.3: Intercept + 'Engine Displacement'
designX = xInt
designX = stats.add_constant(designX, prepend = True)
LLK1, DF1, fullParams1, thisFit = build_mnlogit (designX, y)
testDev = 2.0 * (LLK1 - LLK0)
testDF = DF1 - DF0
testPValue = scipy.stats.chi2.sf(testDev, testDF)
devianceTable = devianceTable.append([[1.3, 'Intercept + Engine Displacement', DF1, LLK1, testDev, testDF, testPValue]])

# Step 1: Intercept + 'Engine Displacement'
designX = xInt
designX = stats.add_constant(designX, prepend = True)
LLK0, DF0, fullParams1, thisFit = build_mnlogit (designX, y)
devianceTable = devianceTable.append([[1, 'Intercept + Engine Displacement', DF0, LLK0, None, None, None]])

# Step 2.1: Intercept + 'Engine Displacement' + 'Air Aspiration Method'
designX = xInt
designX = designX.join(xCat[0])
designX = stats.add_constant(designX, prepend = True)

LLK1, DF1, fullParams1, thisFit = build_mnlogit (designX, y)
testDev = 2.0 * (LLK1 - LLK0)
testDF = DF1 - DF0
testPValue = scipy.stats.chi2.sf(testDev, testDF)
devianceTable = devianceTable.append([[2.1, 'Intercept + Engine Displacement + Air Aspiration Method',
                                       DF1, LLK1, testDev, testDF, testPValue]])

# Step 2.2: Intercept + 'Engine Displacement' + 'Is Unique Label'
designX = xInt
designX = designX.join(xCat[1])
designX = stats.add_constant(designX, prepend = True)

LLK1, DF1, fullParams1, thisFit = build_mnlogit (designX, y)
testDev = 2.0 * (LLK1 - LLK0)
testDF = DF1 - DF0
testPValue = scipy.stats.chi2.sf(testDev, testDF)
devianceTable = devianceTable.append([[2.2, 'Intercept + Engine Displacement + Is Unique Label',
                                       DF1, LLK1, testDev, testDF, testPValue]])
                                 
# Step 2: Intercept + 'Engine Displacement' + 'Air Aspiration Method'
designX = xInt
designX = designX.join(xCat[0])
designX = stats.add_constant(designX, prepend = True)

LLK0, DF0, fullParams1, thisFit = build_mnlogit (designX, y)
devianceTable = devianceTable.append([[2, 'Intercept + Engine Displacement + Air Aspiration Method',
                                       DF0, LLK0, None, None, None]])

# Step 3.1: Intercept + 'Engine Displacement' + 'Air Aspiration Method' + 'Is Unique Label'
designX = xInt
designX = designX.join(xCat[0])
designX = designX.join(xCat[1])
designX = stats.add_constant(designX, prepend = True)

LLK1, DF1, fullParams1, thisFit = build_mnlogit (designX, y)
testDev = 2.0 * (LLK1 - LLK0)
testDF = DF1 - DF0
testPValue = scipy.stats.chi2.sf(testDev, testDF)
devianceTable = devianceTable.append([[3.1, 'Intercept + Engine Displacement + Air Aspiration Method + Is Unique Label',
                                       DF1, LLK1, testDev, testDF, testPValue]])

devianceTable = devianceTable.rename(columns={0:'Sequence', 1:'Model Specification',
                                              2:'Number of Free Parameters', 3:'Log-Likelihood',
                                              4:'Deviance', 5:'Degree of Freedom', 6:'Significance'})

# Final Model: Intercept + 'Engine Displacement' + 'Air Aspiration Method'
designX = xInt
designX = designX.join(xCat[0])
designX = stats.add_constant(designX, prepend = True)

LLK0, DF0, fullParams0, thisFit = build_mnlogit (designX, y)

# Rename the columns of the parameter estimates table
yCat = y.cat.categories
print(yCat)
for i in range(len(yCat)):
    fullParams0 = fullParams0.rename(columns = {i-1: yCat[i] + "(" + str(i-1) + ")"})


