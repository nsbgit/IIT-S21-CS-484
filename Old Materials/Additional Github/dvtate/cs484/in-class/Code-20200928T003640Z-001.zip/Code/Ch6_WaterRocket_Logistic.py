# Name: Ch6_WaterRocket_Logistic.py
# Creation Date: June 10, 2020
# Author: Ming-Long Lam

import matplotlib.pyplot as plt
import numpy
import pandas
import pickle

import statsmodels.api as stats

from matplotlib.ticker import (MultipleLocator, FormatStrFormatter, AutoMinorLocator)

pandas.set_option('precision', 7)

# The SWEEP Operator
def SWEEPOperator (pDim, inputM, tol):
    # pDim: dimension of matrix inputM, positive integer
    # inputM: a square and symmetric matrix, numpy array
    # tol: singularity tolerance, positive real

    aliasParam = []
    nonAliasParam = []
    A = numpy.array(inputM, copy = True, dtype = numpy.float)
    diagA = numpy.diagonal(A)
 
    for k in range(pDim):
        akk = A[k,k]
        if (akk >= (tol * diagA[k])):
            nonAliasParam.append(k)
            for i in range(pDim):
                if (i != k):
                    for j in range(pDim):
                        if (j != k):
                            A[i,j] = A[i,j] - A[i,k] * (A[k,j] / akk)
                            A[j,i] = A[i,j]
                    A[i,k] = A[i,k] / akk
                    A[k,i] = A[i,k]
            A[k,k] = - 1.0 / akk
        else:
            aliasParam.append(k)
            for i in range(pDim):
                A[i,k] = 0.0
                A[k,i] = 0.0
    return A, aliasParam, nonAliasParam

# A function that find the non-aliased columns, fit a logistic model, and return the full parameter estimates
def build_mnlogit (fullX, y):

    # Find the non-redundant columns in the design matrix fullX
    nFullParam = fullX.shape[1]
    XtX = numpy.transpose(fullX).dot(fullX)
    invXtX, aliasParam, nonAliasParam = SWEEPOperator(pDim = nFullParam, inputM = XtX, tol = 1e-13)

    # Build a multionomial logistic model
    X = fullX.iloc[:, list(nonAliasParam)]
    logit = stats.MNLogit(y, X)
    thisFit = logit.fit(method='bfgs', maxiter = 1000, gtol = 1e-6,  
                        full_output = True, disp = True)
    thisParameter = thisFit.params
    thisLLK = logit.loglike(thisParameter.values)
    
    # The number of free parameters
    y_category = y.cat.categories
    nYCat = len(y_category)
    thisDF = len(nonAliasParam) * (nYCat - 1)

    # Return model statistics
    return (thisLLK, thisDF, thisParameter, thisFit)

yName = 'Reached Ceiling'
intName = ['Initial Amount of Water (Kg)', 'Initial Pressure (atm)']

trainData = pandas.read_table('C:\\Machine Learning Book\\Data\\WaterRocket.txt',
                              delimiter = ',', header = None,
                              names = intName + ['Maximum_Height'])

trainData[yName] = numpy.where(trainData['Maximum_Height'] >= 15.0, 'Yes', 'No')

# Specify the color sequence
cmap = ['paleturquoise', 'deepskyblue']

# Generate the contingency table of the interval input feature by the target
for thisName in intName:
    cntTable = pandas.crosstab(index = trainData[thisName], columns = trainData[yName],
                               margins = False, dropna = True)

    # Calculate the row percents
    pctTable = 100.0 * cntTable.div(cntTable.sum(1), axis = 'index')
    yCat = cntTable.columns
    fig, ax = plt.subplots()
    plt.stackplot(pctTable.index, numpy.transpose(pctTable), baseline = 'zero', colors = cmap, labels = yCat)
    ax.xaxis.set_major_locator(MultipleLocator(base = 0.5))
    ax.xaxis.set_minor_locator(MultipleLocator(base = 0.1))
    ax.yaxis.set_major_locator(MultipleLocator(base = 20))
    ax.yaxis.set_major_formatter(FormatStrFormatter('%.0f%%'))
    ax.yaxis.set_minor_locator(MultipleLocator(base = 5))
    ax.set_xlabel(thisName)
    ax.set_ylabel('Percent')
    plt.grid(axis = 'both')
    plt.legend(title = yName, loc = 'lower center', bbox_to_anchor = (0.5, 1), ncol = 2)
    plt.show()

# Rearrange the target categories in this particular order 'No', 'Yes'
u = trainData[yName].astype('category')
y = u.cat.reorder_categories(['No','Yes'])
print('Target Categories:\n', y.cat.categories)

# Train a Logistic Regression model using the all the input features
# Model: Intercept + 'Initial Amout of Water' + 'Initial Pressure'
designX = trainData[intName]
designX = stats.add_constant(designX, prepend = True)
LLK1, DF1, fullParams1, thisFit = build_mnlogit (designX, y)

# Odds ratio by changing Initial Amount of Water (Kg)
b = fullParams1.loc['Initial Amount of Water (Kg)'].values
AmountDiff = numpy.arange(-1.0,1.1,0.1)
OddsRatio = numpy.exp(b * AmountDiff)
fig, ax = plt.subplots()
plt.plot(AmountDiff, OddsRatio)
ax.set_xlabel('Difference in ' + intName[0])
ax.set_ylabel('Odds Ratio')
ax.xaxis.set_major_locator(MultipleLocator(base = 0.2))
ax.xaxis.set_minor_locator(MultipleLocator(base = 0.1))
ax.yaxis.set_major_locator(MultipleLocator(base = 20))
ax.yaxis.set_minor_locator(MultipleLocator(base = 5))
plt.grid(axis = 'both')
plt.show()

# Odds ratio by changing Initial Pressure (atm)
b = fullParams1.loc['Initial Pressure (atm)'].values
AtmDiff = numpy.arange(-3.0,3.1,0.1)
OddsRatio = numpy.exp(b * AtmDiff)
fig, ax = plt.subplots()
plt.plot(AtmDiff, OddsRatio)
ax.set_xlabel('Difference in ' + intName[1])
ax.set_ylabel('Odds Ratio')
ax.xaxis.set_major_locator(MultipleLocator(base = 1.0))
ax.xaxis.set_minor_locator(MultipleLocator(base = 0.2))
ax.yaxis.set_major_locator(MultipleLocator(base = 50))
ax.yaxis.set_minor_locator(MultipleLocator(base = 10))
plt.grid(axis = 'both')
plt.show()

# Create the test cases
designX = pandas.DataFrame()
for w in numpy.arange(0.6, 1.6, 0.2):
    for p in numpy.arange(4.0, 5.5, 0.5):
        designX = designX.append([[1.0, w, p]])
designX = designX.reset_index(drop = True)
designX = designX.rename(columns = {0: 'const', 1: intName[0], 2: intName[1]})

# Calculate the predicted probabilities
predProb = thisFit.predict(designX)
predProb = predProb.rename(columns = {0: 'No', 1: 'Yes'})
predProb['Odds'] = predProb['Yes'] / predProb['No']

testCase = pandas.concat([designX, predProb], axis = 1)

# Write the multinomial logistic model as a Pickle object to an external file

with (open('C:\\Machine Learning Book\\Code\\WaterRocketMNLogistic.pickle', 'wb')) as pFile:
   pickle.dump(thisFit, pFile)
